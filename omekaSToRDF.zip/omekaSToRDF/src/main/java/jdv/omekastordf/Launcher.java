package jdv.omekastordf;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(OmekaToRDFApplication.class, args);
    }
}
